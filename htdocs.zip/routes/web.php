<?php

use Illuminate\Support\Facades\Route;
//use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});
//Route::get('/', function () {
//    return view('login');
//});

//Gudang
Route::get('gudang/Printbahan', 'GudangController@Printbahan')->name("gudang.Printbahan");
Route::get('gudang/Printgudang', 'GudangController@Printgudang')->name("gudang.Printgudang");
Route::get('gudang/listbahanbaku', 'GudangController@listbahanbaku')->name("gudang.listbahanbaku");
//Route::post('gudang/listbahanbaku/approve', 'GudangController@approve')->name("gudang.approve");
Route::match(['put', 'patch'],'gudang/listbahanbaku/{listbahanbaku}/changestatus', 'GudangController@changestatus')->name("gudang.changestatus");
Route::resource("gudang","GudangController");
//Route::resource("Login", "LoginController");


//Produksi
Route::get('produksi/Printproduksi', 'ProduksiController@Printproduksi')->name("produksi.Printproduksi");
Route::resource("produksi", "ProduksiController");

//List Bahan Baku
//Route::resource("listbahanbaku", "ListBahanBakuController");

//Signup
Route::resource("Signup", "SignupController");

//Login
Route::resource("Login", "LoginController");


////Route Halaman Depan
//Route::get('/', 'HomeController@halamanutama');
//
////Route Login Produksi
//Route::get('/loginproduksi', 'HomeController@loginproduksi');
//
////Route Login Produksi Post
//Route::post('/loginprodpost', 'HomeController@loginprodpost');
//
////Route Menu Produksi
//Route::get('/menuproduksi', 'HomeController@menuproduksi');
//
////Route Login Gudang
//Route::get('/logingudang', 'HomeController@logingudang');
//
////Route Login Gudang Post
//Route::post('/logingudangpost', 'HomeController@logingudangpost');
//
////Route Menu Gudang
////Route::get('/formmenugudang', 'HomeController@formmenugudang');
//
////Route Pengajuan Barang
////Route::get('/formpengajuanbarang', 'HomeController@formpengajuanbarang');
//
////Route Tambah Data Bahan Baku
////Route::get('/tambahbahanbaku', 'HomeController@tambahbahanbaku');
//
////Route List Bahan Baku Produksi
////Route::get('/listbahanbakuprod', 'HomeController@listbahanbakuprod');
//
////Route Form list Pengajuan Barang
////Route::get('/formpengajuanbarang', 'HomeController@formpengajuanbarang');
//
////Route Bahan Baku Gudang
////Route::get('/formbahanbakugudang', 'Homecontroller@formbahanbakugudang');
//
////Route Sign Up Gudang
//Route::get('/signupgudang', 'Homecontroller@signupgudang');
//
////Route Sign Up Produksi
//Route::get('/signupproduksi', 'Homecontroller@signupproduksi');
//
//
////******SEPARATOR******//
////Route ADD Pengajuan Barang
////Route::post('/addpengajuanbarang', 'HomeController@addpengajuanbarang');
////Route Submit Pengajuan Barang
////Route::post('/submitpengajuanbarang', 'HomeController@submitpengajuanbarang');
////Route Submit User Produksi
////Route::post('/submituserproduksi', 'HomeController@submituserproduksi');
//
////Route ADD bahan baku
////Route::post('/addbahanbaku', 'HomeController@addbahanbaku');
////Route Submit bahan baku
////Route::post('/submitbahanbaku', 'HomeController@submitbahanbaku');
