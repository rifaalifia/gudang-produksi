<?php

namespace App\Http\Controllers;

use App\Models\ListBahanBaku;
use Illuminate\Http\Request;
use App\Models\Printbahan;

class ListBahanBakuController extends Controller
{

    public function index()
    {
        $listbahanbakus = listbahanbaku::latest()->paginate(5);
        return view("listbahanbaku.index", compact("listbahanbakus"))
            ->with("i", (request()->input("page", 1) - 1) * 5);
    }


    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ListBahanBaku  $listBahanBaku
     * @return \Illuminate\Http\Response
     */
    public function show(ListBahanBaku $listBahanBaku)
    {
        return view("listbahanbaku.show", compact("listBahanBaku"));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ListBahanBaku  $listBahanBaku
     * @return \Illuminate\Http\Response
     */
    public function edit(ListBahanBaku $listBahanBaku)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ListBahanBaku  $listBahanBaku
     * @return \Illuminate\Http\Response
     */
    public function approved(Request $request, ListBahanBaku $listBahanBaku)
    {
        $request->validate([
        ]);

        $produksi->update($request->all());
        return redirect()->route("produksi.index")
            ->with("success", "Produksi updated successfully");
    }

    public function destroy(ListBahanBaku $listBahanBaku)
    {
        //
    }
    public function Printbahan(ListBahanBaku $listBahanBaku)
    {
        $listBahanBaku = Printbahan::latest()->get();
        return view("listBahanBaku.Printbahan", compact("ListBahanBaku"));
    }
}
