<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Session\Session;
use App\User;

class HomeController extends Controller
{
    public function halamanutama()
    {
        return view('halamanutama');
    }

    public function loginproduksi()
    {
        return view('loginproduksi');
    }

    public function logingudang()
    {
        return view('logingudang');
    }

    public function formpengajuanbarang()
    {
        return view('formpengajuanbarang');
    }

    public function tambahbahanbaku()
    {
        return view('tambahbahanbaku');
    }

    public function listbahanbakuprod()
    {
        return view('listbahanbakuprod');
    }

    public function loginprodpost()
    {
        $userproduksi = DB::table('tbl_userproduksi')->get();
        foreach ($userproduksi as $key => $value) {
            var_dump($key, $value);
        }
        die();
        if ($_POST['kodeuser'] == $user &&
            $_POST['password'] == $pass) {
            return redirect("/menuproduksi");
        } else {
            return "LOGIN SALAH";
        }
    }

    public function menuproduksi()
    {
        return view('formmenuproduksi');
    }

    public function logingudangpost()
    {        
        $user = "user";
        $pass = "pass";
        if ($_POST['kodeuser'] == $user &&
            $_POST['password'] == $pass) {
            return redirect("/formmenugudang");
        }
    }

    public function formmenugudang()
    {
        return view('formmenugudang');
    }

    public function addpengajuanbarang(Request $request)
    {
        unset($_POST['_token']);
//        $request->session()->remove("addpengajuanbarang");
        $request->session()->push("addpengajuanbarang", $_POST);
        return redirect("/formpengajuanbarang");
    }

    public function submitpengajuanbarang(Request $request)
    {
        foreach ($request->session()->get('addpengajuanbarang') as $pengajuanbarang) {
            DB::insert("insert into tbl_pengajuanbarang (namabarang,spesifikasi,quantity,untukmesin,keterangan,tanggalpengajuan) values (?,?,?,?,?,?)", [$pengajuanbarang['namabarang'], $pengajuanbarang['spesifikasi'], $pengajuanbarang['quantity'], $pengajuanbarang['untukmesin'], $pengajuanbarang['keterangan'], $pengajuanbarang['tanggalpengajuanbarang']]);
        }
        return redirect("/formpengajuanbarang");
    }

    public function formlistpengajuanbarang()
    {
        return view('formpengajuanbarang');
    }

    public function formbahanbakugudang()
    {
        return view('formbahanbakugudang');
    }

    public function signupgudang()
    {
        return view('signupgudang');
    }

    public function signupproduksi()
    {
        return view('signupproduksi');
    }

    // signup produksi
    public function submituserproduksi()
    {
        DB::insert("insert into tbl_userproduksi (kodeuser,namauser,password) values (?,?,?)", [$_POST['kodeuser'], $_POST['namauser'], $_POST['password']]);
        return redirect('/signupproduksi');
    }

    // Tambah bahan baku gudang
    //public function addbahanbaku(Request $request)
    //{
       // unset($_POST['_token']);
//        $request->session()->remove("addpengajuanbarang");
  //      $request->session()->push("addbahanbaku", $_POST);
   //     return redirect("/formbahanbakugudang");
   // }

   // public function submitbahanbaku(Request $request)
  //  {

 //       foreach ($request->session()->get('addbahanbaku') as $bahanbaku) {
  //          DB::insert("insert into tbl_bahanbaku (kodebarang,namabarang, hargabarang, jumlah,satuan, tanggalmasuk, tanggalkeluar) values (?,?,?,?,?,?,?)", [$bahanbaku['kodebarang'], $bahanbaku['namabarang'], $bahanbaku['hargabarang'], $bahanbaku['jumlah'], $bahanbaku['satuan'], $bahanbaku['tanggalmasuk'], $bahanbaku['tanggalkeluar']]);
  //      }

 }
