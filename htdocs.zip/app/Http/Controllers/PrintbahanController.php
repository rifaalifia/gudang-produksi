<?php

namespace App\Http\Controllers;

use App\Models\Printbahan;
use Illuminate\Http\Request;

class PrintbahanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Printbahan  $printbahan
     * @return \Illuminate\Http\Response
     */
    public function show(Printbahan $printbahan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Printbahan  $printbahan
     * @return \Illuminate\Http\Response
     */
    public function edit(Printbahan $printbahan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Printbahan  $printbahan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Printbahan $printbahan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Printbahan  $printbahan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Printbahan $printbahan)
    {
        //
    }
//    public function Printbahan(Printbahan $printbahan)
//    {
//        $printbahan = Printbahan::latest()->get();
//        return view("gudang.Printbahan", compact("printbahan"));
//    }
}
