<?php

namespace App\Http\Controllers;

use App\Models\Gudang;
use App\Models\Printgudang;
use App\Models\Printbahan;
use Illuminate\Http\Request;
use App\Models\Produksi;

//use App\Models\ListBahanBaku;
use Illuminate\Auth\Events\Login;


class GudangController extends Controller
{
    public function index()
    {
        $gudangs = Gudang::oldest()->get();
        return view("gudang.index", compact("gudangs"))
            ->with("i", (request()->input("page", 1) - 1) * 5);
    }

    public function create()
    {
        return view("gudang.create");
    }

    public function listbahanbaku(Produksi $produksi)
    {
//        $listbahanbakus = Produksi::oldest()->get();
        $listbahanbakus = Produksi::oldest()->get();
        return view("gudang.listbahanbaku", compact("listbahanbakus"))
            ->with("i", (request()->input("page", 1) - 1) * 5);
    }

    public function changestatus(Request $request, Produksi $produksi)
    {
        $prod = Produksi::find($request->get('id'));
        $matchThese = [
            'namabarang' => $prod->namabarang,
            'spesifikasi' => $prod->spesifikasi,
        ];
        $guds = Gudang::where($matchThese)->get();
        // 1. Kondisi dimana klik tombol submit Approve
        if ($request->get('status') == "approve") {
            foreach ($guds as $gud) {
                // 1.1 Kondisi dimana Stock di gudang mencukupi
                if ((int)$gud->jumlah >= (int)$prod->quantity) {
                    $gud->jumlah = (int)$gud->jumlah - (int)$prod->quantity;
                    $gud->jumlah = (string)$gud->jumlah;
                    $gud->save();
                    $prod->status = $request->get('status');
                    $prod->save();
                    return redirect()->route("gudang.listbahanbaku")
                        ->with("success", "List Bahan Baku Change Status successfully");
                }
                // 1.2 Kondisi dimana Stock di gudang tidak mencukupi
                else {
                    return redirect()->route("gudang.listbahanbaku")
                        ->with("unsuccess", "List Bahan Baku Change Status Unsuccessfully");
                }
            }
        }
        // 2. Kondisi dimana klik tombol submit Unapprove (salah klik))
        else{
            foreach ($guds as $gud) {
                $gud->jumlah = (int)$gud->jumlah + (int)$prod->quantity;
                $gud->jumlah = (string)$gud->jumlah;
                $gud->save();
            }
            $prod->status = $request->get('status');
            $prod->save();
            return redirect()->route("gudang.listbahanbaku")
                ->with("unsuccess", "List Bahan Baku Change Status Unsuccessfully");
        }
    }

    public function store(Request $request)
    {
        $request->validate([
            "namabarang" => "required",
            "spesifikasi" => "required",
            "jumlah" => "required",
            "satuan" => "required",
            "tanggalmasuk" => "required",
            "tanggalkeluar" => "required",
        ]);

        Gudang::create($request->all());

        return redirect()->route("gudang.index")
            ->with("success", "Gudang created successfully");
    }

    public function show(Gudang $gudang)
    {
        return view("gudang.show", compact("gudang"));
    }

    public function edit(Gudang $gudang)
    {
        return view("gudang.edit", compact("gudang"));
    }

    public function update(Request $request, Gudang $gudang)
    {
        $request->validate([]);

        $gudang->update($request->all());

        return redirect()->route("gudang.index")
            ->with("success", "Gudang updated successfully");
    }

    public function destroy(Gudang $Gudang)
    {
        $Gudang->delete();
        return redirect()->route("gudang.index")
            ->with("success", "Gudang deleted successfully");
    }

    public function login(Login $login)
    {
        return view("login.index");
    }

    public function Printgudang(Gudang $gudang)
    {
        $gudang = Printgudang::oldest()->get();
        return view("gudang.Printgudang", compact("gudang"));
    }

    public function Printbahan(Printbahan $printbahan)
    {
        $bahanbaku = Printbahan::oldest()->get();
        return view("gudang.Printbahan", compact("bahanbaku"));
    }


}
