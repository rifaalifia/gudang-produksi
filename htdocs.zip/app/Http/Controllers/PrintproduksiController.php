<?php

namespace App\Http\Controllers;

use App\Models\Printproduksi;
use Illuminate\Http\Request;

class PrintproduksiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Printproduksi  $printproduksi
     * @return \Illuminate\Http\Response
     */
    public function show(Printproduksi $printproduksi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Printproduksi  $printproduksi
     * @return \Illuminate\Http\Response
     */
    public function edit(Printproduksi $printproduksi)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Printproduksi  $printproduksi
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Printproduksi $printproduksi)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Printproduksi  $printproduksi
     * @return \Illuminate\Http\Response
     */
    public function destroy(Printproduksi $printproduksi)
    {
        //
    }
}
