<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Pengajuan Bahan Baku Produksi</title>
</head>
<body>
<form>
    <table border="2" cellpadding="5">
        <tr>
            <td>Nomor</td>
            <td>Nama Barang</td>
            <td>Spesifikasi</td>
            <td>Quantity</td>
            <td>Untuk Mesin</td>
            <td>Keterangan</td>
            <td>Tanggal Pengajuan Barang</td>
            <td>Status</td>
        </tr>

            <td><button>Submit</button></td>
        </tr>
    </table>
</form>
</body>
</html>
