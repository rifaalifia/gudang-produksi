<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view("login.index");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, User $user)
    {
        $request->validate([
            "email" => "required",
            "password" => "required",
            "kategori" => "required",
        ]);
        $is_email = User::Where('email', $request->get('email'))->get();
        $is_email_valid = count($is_email) > 0;
        $is_password = User::Where('password', $request->get('password'))->get();
        $is_password_valid = count($is_password) > 0;
        $is_kategori = User::Where('kategori', $request->get('kategori'))->get();
        $is_kategori_valid = count($is_kategori) > 0;
        if($is_email_valid && $is_password_valid && $is_kategori_valid){
            if($request->get('kategori') == "gudang"){
                return redirect()->route("gudang.index")
                    ->with("success", "Login Successfully");
            }elseif ($request->get('kategori') == "produksi"){
                return redirect()->route("produksi.index")
                    ->with("success", "Login Successfully");
            }else{
                return redirect()->route("Login.index")
                    ->with("success", "Login Successfully");
            }
        }else{
            return redirect()->route("Login.index")
                ->with("unsuccess", "Login Unsuccessfully");
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
