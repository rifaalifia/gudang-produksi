<?php

namespace App\Http\Controllers;

use App\Models\Printproduksi;
use App\Models\Produksi;
use App\Models\Gudang;
use Illuminate\Http\Request;
//use App\Models\Printproduksi;

class ProduksiController extends Controller
{
    public function index()
    {
        $produksis = produksi::oldest()->get();
        return view("produksi.index", compact("produksis"))
            ->with("i", (request()->input("page", 1) - 1) * 5);
    }

    public function create(Gudang $gudang_var)
    {
        $gudangs = Gudang::oldest()->get();
        $arrayNamaBarang = [];
        foreach ($gudangs as $ga){
            array_push($arrayNamaBarang, $ga->namabarang);
        }
        $arrayNamaBarang = array_unique($arrayNamaBarang);
        return view("produksi.create", compact("gudangs","arrayNamaBarang"));
    }

    public function store(Request $request)
    {
        $request->validate([
            "namabarang" => "required",
            "spesifikasi" => "required",
            "quantity" => "required",
            "untukmesin" => "required",
            "keterangan" => "required",
            "tanggalpengajuan" => "required",
            "status" => "required",
        ]);

        produksi::create($request->all());

        return redirect()->route("produksi.index")
            ->with("success", "Produksi created successfully");
    }

    public function show(Produksi $produksi)
    {
        return redirect()->route("produksi.index")
            ->with("success", "Send successfully");

//        return view("produksi.show", compact("produksi"))
//            ->with("success", "Send successfully");
    }

    public function edit(Produksi $produksi)
    {
        return view("produksi.edit", compact("produksi"));
    }

    public function update(Request $request, Produksi $produksi)
    {
        $request->validate([
        ]);

        $produksi->update($request->all());
        return redirect()->route("produksi.index")
            ->with("success", "Produksi updated successfully");
    }

    public function destroy(Produksi $produksi)
    {
        $produksi->delete();
        return redirect()->route("produksi.index")
            ->with("success", "Produksi deleted successfully");
    }
    public function login(Login $login)
    {
        return view("login.index");
    }
    public function Printproduksi(Produksi $produksi)
    {
        $produksi = Printproduksi::oldest()->get();
        return view("produksi.Printproduksi", compact("produksi"));
    }
}
