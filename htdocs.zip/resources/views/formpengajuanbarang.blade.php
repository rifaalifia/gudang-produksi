<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pengajuan Barang</title>
</head>
<body>
<form action="/addpengajuanbarang" method="POST">
    {{ csrf_field() }}
    <div>
        <label>Nama Barang</label> <br>
        <input id="namabarang" name="namabarang" type="text" placeholder="Masukkan nama barang" required>
    </div>
    <div>
        <label>Spesifikasi</label> <br>
        <input id="spesifikasi" name="spesifikasi" type="text" placeholder="Masukkan spesifikasi" required>
    </div>
    <div>
        <label>Quantity</label> <br>
        <input id="quantity" name="quantity" type="number" placeholder="Masukkan quantity" required>
    </div>
    <div>
        <label>Untuk Mesin</label> <br>
        <input id="untukmesin" name="untukmesin" type="text" placeholder="Masukkan Untuk Mesin" required>
    </div>
    <div>
        <label>Keterangan</label> <br>
        <input id="keterangan" name="keterangan" type="text" placeholder="Masukkan Keteranga" required>
    </div>
    <div>
        <label>Tanggal Pengajuan Barang</label> <br>
        <input id="tanggalpengajuanbarang" name="tanggalpengajuanbarang" type="date" placeholder="Masukkan Tanggal Pengajuan Barang" required>
    </div>
    <div>
        <button type="submit" id="addpengajuanbarang">ADD</button>
    </div>
</form>

<form action="/submitpengajuanbarang" method="POST">
    {{ csrf_field() }}
<table border="2" cellpadding="5">
    <tr>
        <td>Nama Barang</td>
        <td>Spesifikasi</td>
        <td>Quantity</td>
        <td>Untuk Mesin</td>
        <td>Keterangan</td>
        <td>Tanggal Pengajuan Barang</td>
    </tr>

        <?php
        if(null !== Session::get('addpengajuanbarang')){
            $nomorbarang = Session::get('addpengajuanbarang');
            foreach ($nomorbarang as $nomor){
                echo "<tr>";
                foreach ($nomor as $value){
                    echo "<td>".$value."</td>";
                }
                echo "</tr>";
            }
        }
        ?>

</table>
<button type="submit">SUBMIT</button>
</form>
</body>
</html>
