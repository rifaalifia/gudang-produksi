<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM DATA BAHAN BAKU GUDANG</title>
</head>
<body>
<div>
    <a href="/tambahbahanbaku">
        <button type="submit">ADD</button>
    </a>
</div>
<div>
    <a href="/tambahbahanbaku">
        <button type="submit">EDIT</button>
    </a>
</div>
<div>
    <button>Print_PDF</button>
</div>
<form> action="/submitbahanbaku" method="POST">
        {{ csrf_field() }}
    <table border="2" cellpadding="5">
        <tr>
            <td>Nomor</td>
            <td>Kode Barang</td>
            <td>Nama Barang</td>
            <td>Harga Barang</td>
            <td>Jumlah</td>
            <td>Satuan</td>
            <td>Tanggal Masuk Barang</td>
            <td>Tanggal Keluar Barang</td>
        </tr>
    </table>

</form>
</body>
</html>
