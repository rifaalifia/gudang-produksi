<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM DATA TAMBAH BAHAN BAKU</title>
</head>
<body>
<form> action="/addbahanbaku" method="POST">
    {{ csrf_field() }}
    <div>
        <label>Kode Barang</label> <br>
        <input name="kode_barang" type="text" placeholder="Masukkan kode barang">
    </div>
    <div>
        <label>Nama Barang</label> <br>
        <input name="nama_barang" type="text" placeholder="Masukkan nama barang">
    </div>
    <div>
        <label>Harga</label> <br>
        <input name="harga" type="number" placeholder="Masukkan harga">
    </div>
    <div>
        <label>Jumlah</label> <br>
        <input name="jumlah" type="number" placeholder="Masukkan Jumlah">
    </div>
    <div>
        <label>Satuan</label> <br>
        <input name="satuan" type="text" placeholder="Masukkan satuan">
    </div>
    <div>
        <label>Tanggal Masuk</label> <br>
        <input name="tanggal_masuk" type="date" placeholder="Masukkan tanggal pemasukan">
    </div>
    <div>
        <label>Taggal Keluar</label> <br>
        <input name="tanggal_keluar" type="date" placeholder="Masukkan tanggal pengluaran"
    </div>
    <div>
        <button type="submit" id="addbahanbaku">SIMPAN</button>
    </div>
    <div>
        <button>Print_PDF</button>
    </div>
</form>

<form action="/addbahanbaku" method="POST">
{{ csrf_field() }}
</body>
</html>
