<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM SIGN UP PRODUKSI</title>
</head>
<body>
<form action="/submituserproduksi" method="POST">
{{ csrf_field() }}
    <div>
        <label>Kode User</label> <br>
        <input name="kodeuser" type="text" placeholder="Masukkan kode user">
    </div>
    <div>
        <label>Nama User</label> <br>
        <input name="namauser" type="text" placeholder="Masukkan nama user">
    </div>
    <div>
        <label>Password</label> <br>
        <input name="password" type="password" placeholder="Masukkan password">
    </div>
    <div>
        <button type="submit">DAFTAR</button>
    </div>
</form>
</body>

</html>
