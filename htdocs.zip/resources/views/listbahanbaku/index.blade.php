@extends("listbahanbaku.layout")
@section("content")
    <div class="pull-left">
        <h2>List Bahan Baku</h2>
    </div>


    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Spesifikasi</th>
            <th>Quantity</th>
            <th>Untuk Mesin</th>
            <th>Keterangan</th>
            <th>Tanggal Pengajuan</th>
            <th width="280px">Action</th>
        </tr>

        @foreach ($listbahanbakus as $listbahanbaku)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $listbahanbaku->namabarang}}</td>
                <td>{{ $listbahanbaku->spesifikasi}}</td>
                <td>{{ $listbahanbaku->quantity}}</td>
                <td>{{ $listbahanbaku->untukmesin}}</td>
                <td>{{ $listbahanbaku->keterangan}}</td>
                <td>{{ $listbahanbaku->tangalpengajuan}}</td>
                <td>
                    <form action ="{{ route("listbahanbaku.approved",$listbahanbaku->id) }}" method="POST">
                        @csrf

                    </form>
                </td>
            </tr>
        @endforeach
    </table>
