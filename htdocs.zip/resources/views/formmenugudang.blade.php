<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MENU GUDANG</title>
</head>
<body>
<div>
    <a href="/listbahanbakuprod">
        <button type="submit">LIST BAHAN BAKU PRODUKSI</button>
    </a>
</div>
<div>
    <a href="/formbahanbakugudang">
        <button type="submit">FORM DATA BAHAN BAKU GUDANG</button>
    </a>
</div>
</body>
</html>

