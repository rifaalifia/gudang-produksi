<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form List Pengajuan Bahan Baku Produksi</title>
</head>
<body>
<form>
    <table border="2" cellpadding="5">
        <tr>
            <td>Nomor</td>
            <td>Nama Barang</td>
            <td>Spesifikasi</td>
            <td>Quantity</td>
            <td>Untuk Mesin</td>
            <td>Keterangan</td>
            <td>Tanggal Pengajuan Barang</td>
            <td>Status</td>
        </tr>
        <?php
        echo "<pre>";
        var_dump($results = DB::select('select * from tbl_listbahanbakuproduksi', ['id' => 1]));
        echo "</pre>";
        die();
        ?>
        <tr>
            <td>1</td>
            <td>Kayu</td>
            <td>Jati</td>
            <td>5</td>
            <td>Kayu</td>
            <td>-</td>
            <td>10 Maret 2021</td>
            <td><button>Approved</button></td>
        </tr>
    </table>
</form>
</body>
</html>
