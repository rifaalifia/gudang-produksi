<!DOCTYPE html>
<html>
<head>
    <title>Sign Up Gudang</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    @yield("content")
</div>
</body>
</html>
