<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateListbahanbakuTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('listbahanbaku', function (Blueprint $table) {
            $table->id();
            $table->string('namabarang');
            $table->string('spesifikasi');
            $table->string('quantity');
            $table->string('untukmesin');
            $table->string('keterangan');
            $table->string('tanggalpengajuan');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('listbahanbaku');
    }
}
