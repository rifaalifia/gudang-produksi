<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM SIGN UP GUDANG</title>
</head>
<body>
<form>
    <div>
        <label>Kode User</label> <br>
        <input name="kode_barang" type="text" placeholder="Masukkan kode barang">
    </div>
    <div>
        <label>Nama User</label> <br>
        <input name="nama_barang" type="text" placeholder="Masukkan nama barang">
    </div>
    <div>
        <label>Password</label> <br>
        <input name="password" type="text" placeholder="Masukkan password">
    </div>
    <div>
        <button>Daftar</button>
    </div>
</form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\resources\views/signupgudang.blade.php ENDPATH**/ ?>