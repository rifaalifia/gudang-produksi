<?php $__env->startSection("content"); ?>
    <div class="pull-left">
        <h2>PRODUKSI</h2>
    </div>


    <div class="pull-right">
        <a class="btn btn-primary" href="<?php echo e(route("Login.index")); ?>"> Logout</a>
    </div>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route("produksi.create")); ?>">create new pengajuan barang</a>
                <a target="_blank" class="btn btn-primary" href="<?php echo e(route("produksi.Printproduksi")); ?>"> Print Data Pengajuan Barang Produksi <i class="fas fa-print"></i></a>
            </div>
        </div>
    </div>
    <?php if($message = Session::get("success")): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Spesifikasi</th>
            <th>Quantity</th>
            <th>Untuk Mesin</th>
            <th>Keterangan</th>
            <th>Tanggal Pengajuan</th>
            <th>Status</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $produksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($produksi->namabarang); ?></td>
                <td><?php echo e($produksi->spesifikasi); ?></td>
                <td><?php echo e($produksi->quantity); ?></td>
                <td><?php echo e($produksi->untukmesin); ?></td>
                <td><?php echo e($produksi->keterangan); ?></td>
                <td><?php echo e($produksi->tanggalpengajuan); ?></td>
                <td><?php echo e($produksi->status); ?></td>
                <td>
                    <form action ="<?php echo e(route("produksi.destroy",$produksi->id)); ?>" method="POST">
                        <a class="btn btn-success" href="<?php echo e(route("produksi.show",$produksi->id)); ?>">Send</a>
                        <a class="btn btn-primary" href="<?php echo e(route("produksi.edit",$produksi->id)); ?>">Edit</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>

                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php echo $__env->make("produksi.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/produksi/index.blade.php ENDPATH**/ ?>