<?php $__env->startSection("content"); ?>

    <h2>LOGIN</h2>

    <form action="<?php echo e(route("Login.store")); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Email</strong>
                    <input type="text" name="email" class="form-control" placeholder="Email">

                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Password</strong>
                    <input type="password" name="password" class="form-control" placeholder="Password">

                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Kategori</strong>
                    <select name="kategori" class="form-control" >
                        <option value="gudang" selected='selected'>gudang
                        </option>
                        <option value="produksi" >produksi
                        </option>
                    </select>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Masuk</button>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <a href="/Signup">
                    <button type="button" class="btn btn-info">Daftar</button>
                </a>
            </div>
        </div>
    </form>

    <?php if($message = Session::get("success")): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get("unsuccess")): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("login.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/login/index.blade.php ENDPATH**/ ?>