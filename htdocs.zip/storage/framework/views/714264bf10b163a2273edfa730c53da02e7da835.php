<?php $__env->startSection("content"); ?>
    <div class="pull-left">
        <h2>List Bahan Baku</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-primary" href="<?php echo e(route("gudang.index")); ?>"> Back</a>
    </div>

    <div class="pull-right">
        <a target="_blank" class="btn btn-primary" href="<?php echo e(route("gudang.Printbahan")); ?>"> Print List Bahan Baku <i class="fas fa-print"></i></a>
    </div>

    <?php if($message = Session::get("success")): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get("unsuccess")): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Spesifikasi</th>
            <th>Quantity</th>
            <th>Untuk Mesin</th>
            <th>Keterangan</th>
            <th>Tanggal Pengajuan</th>
            <th>Status</th>
            <th width="280px">Action</th>
        </tr>

        <?php $__currentLoopData = $listbahanbakus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listbahanbaku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($listbahanbaku->id); ?></td>
                <td><?php echo e($listbahanbaku->namabarang); ?></td>
                <td><?php echo e($listbahanbaku->spesifikasi); ?></td>
                <td><?php echo e($listbahanbaku->quantity); ?></td>
                <td><?php echo e($listbahanbaku->untukmesin); ?></td>
                <td><?php echo e($listbahanbaku->keterangan); ?></td>
                <td><?php echo e($listbahanbaku->tanggalpengajuan); ?></td>
                <td><?php echo e($listbahanbaku->status); ?></td>
                <td>
                    <?php if($listbahanbaku->status == "unapprove"): ?>
                        <form action="<?php echo e(route("gudang.changestatus",$listbahanbaku->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <input type="hidden" name="id" value="<?php echo e($listbahanbaku->id); ?>">
                            <input type="hidden" name="status" value="approve">
                            <button type="submit" class="btn btn-primary">Approve</button>
                        </form>
                    <?php endif; ?>
                    <?php if($listbahanbaku->status == "approve"): ?>
                        <form action="<?php echo e(route("gudang.changestatus",$listbahanbaku->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <input type="hidden" name="id" value="<?php echo e($listbahanbaku->id); ?>">
                            <input type="hidden" name="status" value="unapprove">
                            <button type="submit" class="btn btn-danger">Unapprove</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php echo $__env->make("gudang.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/gudang/listbahanbaku.blade.php ENDPATH**/ ?>