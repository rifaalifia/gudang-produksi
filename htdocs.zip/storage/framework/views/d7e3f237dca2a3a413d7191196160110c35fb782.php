<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <?php echo $__env->yieldContent("content"); ?>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\resources\views/login/layout.blade.php ENDPATH**/ ?>