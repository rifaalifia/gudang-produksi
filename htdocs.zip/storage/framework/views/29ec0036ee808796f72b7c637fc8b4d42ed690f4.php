<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <style>
        table.static {
            position: relative;
            border: 1px solid #543535;

        }
    </style>
    <title>PRINT DATA LIST BAHAN BAKU</title>
</head>
<body>
<div class="form-group">
    <p align="center"><b>LAPORAN LIST BAHAN BAKU</b></p>
    <table class="static" align="center" rules="all" border="1px" style="width: 95%;">
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Spesifikasi</th>
            <th>Quantity</th>
            <th>Untuk Mesin</th>
            <th>Keterangan</th>
            <th>Tanggal Pengajuan</th>
            <th>Status</th>
        </tr>
        <?php $__currentLoopData = $bahanbaku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Printbahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($Printbahan->namabarang); ?></td>
                <td><?php echo e($Printbahan->spesifikasi); ?></td>
                <td><?php echo e($Printbahan->quantity); ?></td>
                <td><?php echo e($Printbahan->untukmesin); ?></td>
                <td><?php echo e($Printbahan->keterangan); ?></td>
                <td><?php echo e($Printbahan->tanggalpengajuan); ?></td>
                <td><?php echo e($Printbahan->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<script type="text/javascript ">
    window.print();
</script>

</body>

</html>


<?php /**PATH C:\xampp\htdocs\resources\views/gudang/Printbahan.blade.php ENDPATH**/ ?>