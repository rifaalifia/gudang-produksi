<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Product</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route("produksi.index")); ?>">Back</a>
            </div>
        </div>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route("produksi.update",$produksi->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nama Barang</strong>
                    <input type="text" name="namabarang" value="<?php echo e($produksi->namabarang); ?>" class="form-control" placeholder="Nama Barang">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Spesifikasi</strong>
                    <input type="text" name="spesifikasi" value="<?php echo e($produksi->spesifikasi); ?>" class="form-control" placeholder="Spesifikasi">

                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Quantity</strong>
                    <input type="text" name="quantity" value="<?php echo e($produksi->quantity); ?>"  class="form-control" placeholder="Quantity">

                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Untuk Mesin</strong>
                    <input type="text" name="untukmesin" value="<?php echo e($produksi->untukmesin); ?>" class="form-control" placeholder="Untuk Mesin">

                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Keterangan</strong>
                    <input type="text" name="keterangan" value="<?php echo e($produksi->keterangan); ?>" class="form-control" placeholder="Keterangan">

                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Tanggal Pengajuan</strong>
                    <input type="date" name="tanggalpengajuan" value="<?php echo e($produksi->tanggalpengajuan); ?>" class="form-control" placeholder="Tanggal Pengajuanr">

                </div>
            </div>
            <input type="hidden" name="status" value="unapprove">

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("produksi.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/produksi/edit.blade.php ENDPATH**/ ?>